This directory contains files used for validation of upnpreplyparse.c code.

Each .xml file to parse should give the results which are in the .namevalue
file.

A .namevalue file contain name=value lines.

